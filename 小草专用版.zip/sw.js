// 渡念 Service Worker - 后台消息通知
// 极简实现，只负责显示通知和处理点击跳转

self.addEventListener('install', function(event) {
  self.skipWaiting();
});

self.addEventListener('activate', function(event) {
  event.waitUntil(self.clients.claim());
});

// 点击通知：聚焦或打开对应聊天
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  var chatId = event.notification.data && event.notification.data.chatId;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
      // 已经有打开的页面，聚焦它并发消息跳转
      for (var i = 0; i < clientList.length; i++) {
        var client = clientList[i];
        if ('focus' in client) {
          client.postMessage({ type: 'notify-click', chatId: chatId });
          return client.focus();
        }
      }
      // 没有打开的页面，打开首页
      if (self.clients.openWindow) {
        return self.clients.openWindow('./');
      }
    })
  );
});
